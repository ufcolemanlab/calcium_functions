# -*- coding: utf-8 -*-

"""

Created on Mon Feb 06 07:43:50 2017

@author: Jesse Trinity, Jason Coleman

These modules are to be used with Coleman lab "calcium imaging scripts".


"""
__author__ = "Coleman Lab <colemanlabuf@gmail.com>"
__license__ = "PSF License"
__version__ = "1.0"
